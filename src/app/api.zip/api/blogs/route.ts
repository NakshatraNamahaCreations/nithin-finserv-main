import { NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";
import Blog from "@/lib/models/Blog";

export async function GET() {
  try {
    await connectDB();

    const blogs = await Blog.find().sort({
      createdAt: -1,
    });

    return NextResponse.json(blogs);
  } catch (error) {
    console.log(error);

    return NextResponse.json(
      {
        error: "Failed to fetch blogs",
      },
      {
        status: 500,
      }
    );
  }
}

export async function POST(req: Request) {
  try {
    await connectDB();

    const body = await req.json();

    const blog = await Blog.create(body);

    return NextResponse.json(blog);
  } catch (error) {
  console.log("MONGODB ERROR:", error);

  return NextResponse.json(
    {
      error: "Failed to fetch blogs",
      details:
        error instanceof Error
          ? error.message
          : "Unknown error",
    },
    {
      status: 500,
    }
  );
}
}